﻿/*
 * Created by SharpDevelop.
 * User: Administrator
 * Date: 18.11.2018
 * Time: 23:10
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Caser_Bantugan.Models
{
    /// <summary>
    /// Description of Exam.
    /// </summary>
    public class Exam
    {
        public int ExID { get; set; }
        public string ExName { get; set; }
        public double Score { get; set; }
        public double Grade { get; set; }
        public ExamType studentExamType = new ExamType();

        public double CompExam(int examtype, double MyScore)
        {
            if (examtype == System.Convert.ToInt32(ExamType.regular))
            {
                Score = MyScore / 50 * 0.1;
                //return Score;
            }
            else if (examtype == System.Convert.ToInt32(ExamType.regular))
            {
                Score = MyScore / 100 * 0.6;
                //return Score;
            }
            return Score;
        }


    }
}