﻿/*
 * Created by SharpDevelop.
 * User: Administrator
 * Date: 18.11.2018
 * Time: 23:11
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace Caser_Bantugan.Models
{
    /// <summary>
    /// Description of Student.
    /// </summary>
    public class Student : Person
    {
        public int ID { get; set; }
        public int StudNum { get; set; }
        public double FinGrade { get; set; }
        public double AveGrade { get; set; }
        public List<double> myGrade = new List<double>();

        public void CompGrade(double quizScore, double examScore)
        {
            FinGrade = quizScore + examScore;
            AveGrade = (quizScore + examScore) / 2;

            Console.WriteLine("Final Grade: " + FinGrade);
            Console.WriteLine("Average Grade: " + AveGrade);
            if (AveGrade >= 60)
                Console.WriteLine("Passed!");
            else
                Console.WriteLine("Failed!");

        }
    }
}

