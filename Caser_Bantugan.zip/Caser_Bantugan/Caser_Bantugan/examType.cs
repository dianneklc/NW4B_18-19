﻿/*
 * Created by SharpDevelop.
 * User: Administrator
 * Date: 18.11.2018
 * Time: 23:11
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Caser_Bantugan.Models
{
    /// <summary>
    /// Description of ExamType.
    /// </summary>
    public class ExamType
    {
        public static Enum regular { get; set; }
    }
}
