﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Caser_Bantugan.Models;

namespace Caser_Bantugan
{
    class Program
    {
        public static void Main(string[] args)
        {
            Student newStudent = new Student();
            Exam myExam = new Exam();
            int ctr = 0;
            int quiznum = 1;
            double quizScore, examScore, myExamScore, myQuiz;
            do
            {
                Console.Clear();
                myExam.Score = 0;
                examScore = 0;

                try
                {
                    Console.WriteLine("Student number: ");
                    newStudent.StudNum = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Name: ");
                    newStudent.Name = Console.ReadLine();
                    Console.WriteLine("Age: ");
                    newStudent.Age = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Gender: ");
                    newStudent.Gender = Console.ReadLine();

                }
                catch (Exception e)
                {
                    Console.WriteLine("Student number should be numeric!" + e);
                }

                for (int i = 1; i <= 4; i++)
                {
                    Console.WriteLine("Quiz " + i + " :");
                    quizScore = Convert.ToDouble(Console.ReadLine());
                    newStudent.myGrade.Add(quizScore);
                    myQuiz = myExam.CompExam(0, quizScore);
                    myExam.Score += quizScore;
                }

                Console.WriteLine("Final Exam: ");
                examScore = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("\n\nPress key to continue. ");
                Console.ReadKey();
                Console.Clear();

                foreach (var e in newStudent.myGrade)
                {
                    Console.WriteLine("Quiz " + quiznum + ": " + e);
                    quiznum++;
                }

                Console.WriteLine("Final Exam: " + examScore);

                newStudent.myGrade.Add(examScore);
                myExamScore = myExam.CompExam(1, examScore);
                newStudent.CompGrade(myExam.Score, myExamScore);

                Console.WriteLine("\n\nPress any number to continue. ");
                Console.WriteLine("Press 1 to EXIT. ");
                ctr = Convert.ToInt32(Console.ReadLine());

            }
            while (ctr != 1);
        }
    }
}