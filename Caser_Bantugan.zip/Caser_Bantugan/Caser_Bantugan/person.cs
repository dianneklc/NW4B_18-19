﻿/*
 * Created by SharpDevelop.
 * User: Administrator
 * Date: 18.11.2018
 * Time: 23:10
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Caser_Bantugan.Models
{
    /// <summary>
    /// Description of Person.
    /// </summary>
    public class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
    }
}
